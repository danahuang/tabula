package technology.tabula;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;

import org.junit.Test;
import technology.tabula.debug.Debug;

public class TestDebug {

    private final static String PATH = "src/test/resources/technology/tabula/spanning_cells.pdf";
        
//    @Test
//    public void test() throws IOException {
//        File outFile = new File(new File(System.getProperty("java.io.tmpdir")), "/rendered_page.jpg");
//        Debug.renderPage(PATH, outFile.getAbsolutePath(), 0, null, true, false, false, false, false, false, false, false, false, false);
//        assertTrue(outFile.exists());
//        System.out.println(outFile.getAbsolutePath());
//    }

}
