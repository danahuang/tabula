package technology.tabula;

public interface HasText {
    
    String getText();

}
